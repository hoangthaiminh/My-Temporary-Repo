"""Native mouse controls and comprehensive, read-only inspection reports."""
from __future__ import annotations

import ctypes as C
from ctypes import wintypes as W
from dataclasses import dataclass, field
from datetime import datetime
import json
import os
import queue
import threading
from typing import Any


def timestamp():
    return datetime.now().astimezone().isoformat(timespec="milliseconds")


def unavailable(reason, **details):
    return {"available": False, "reason": str(reason), **details}


def read(getter):
    try:
        return json_value(getter())
    except Exception as exc:
        return unavailable(f"{type(exc).__name__}: {exc}")


def json_value(value):
    if hasattr(value, "_asdict"):
        return {k: json_value(v) for k, v in value._asdict().items()}
    if isinstance(value, dict):
        return {str(k): json_value(v) for k, v in value.items()}
    if isinstance(value, (tuple, list, set)):
        return [json_value(v) for v in value]
    if isinstance(value, bytes):
        return {"encoding": "hex", "value": value.hex()}
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    return str(value)


class MouseGate:
    """Match swallowed button releases even if inspection is paused mid-click."""

    def __init__(self):
        self.enabled = True
        self.blocked = set()

    def handle(self, message):
        down = {0x0201: "freeze", 0x0204: "copy"}
        up = {0x0202: "freeze", 0x0205: "copy"}
        if message in down:
            action = down[message]
            if self.enabled:
                self.blocked.add(action)
                return True, action
        elif message in up:
            action = up[message]
            if action in self.blocked:
                self.blocked.remove(action)
                return True, None
        return False, None


class MouseHook:
    """A dedicated message-pump thread keeps the low-level hook responsive."""

    def __init__(self, actions):
        self.actions = actions
        self.gate = MouseGate()
        self.ready = threading.Event()
        self.stopped = threading.Event()
        self.error = None
        self.thread_id = None
        self.user = C.WinDLL("user32", use_last_error=True)
        self.kernel = C.WinDLL("kernel32", use_last_error=True)
        self.callback_type = C.WINFUNCTYPE(C.c_ssize_t, C.c_int, W.WPARAM, W.LPARAM)

        class MouseInfo(C.Structure):
            _fields_ = [("point", W.POINT), ("mouse_data", W.DWORD),
                        ("flags", W.DWORD), ("time", W.DWORD), ("extra", C.c_size_t)]

        self.info_type = MouseInfo
        self.user.SetWindowsHookExW.argtypes = [C.c_int, self.callback_type, W.HINSTANCE, W.DWORD]
        self.user.SetWindowsHookExW.restype = W.HANDLE
        self.user.CallNextHookEx.argtypes = [W.HANDLE, C.c_int, W.WPARAM, W.LPARAM]
        self.user.CallNextHookEx.restype = C.c_ssize_t
        self.user.UnhookWindowsHookEx.argtypes = [W.HANDLE]
        self.user.UnhookWindowsHookEx.restype = W.BOOL
        self.user.GetMessageW.argtypes = [C.POINTER(W.MSG), W.HWND, W.UINT, W.UINT]
        self.user.GetMessageW.restype = C.c_int
        self.user.PeekMessageW.argtypes = [C.POINTER(W.MSG), W.HWND, W.UINT, W.UINT, W.UINT]
        self.user.PeekMessageW.restype = W.BOOL
        self.user.PostThreadMessageW.argtypes = [W.DWORD, W.UINT, W.WPARAM, W.LPARAM]
        self.user.PostThreadMessageW.restype = W.BOOL
        self.kernel.GetCurrentThreadId.argtypes = []
        self.kernel.GetCurrentThreadId.restype = W.DWORD
        self.kernel.GetModuleHandleW.argtypes = [W.LPCWSTR]
        self.kernel.GetModuleHandleW.restype = W.HMODULE
        self.thread = threading.Thread(target=self._run, name="InspectorMouseHook", daemon=True)

    def start(self):
        self.thread.start()
        if not self.ready.wait(5):
            self.stop()
            raise RuntimeError("Timed out while starting the mouse hook.")
        if self.error:
            raise RuntimeError(self.error)

    def _run(self):
        hook = None
        try:
            self.thread_id = self.kernel.GetCurrentThreadId()

            @self.callback_type
            def callback(code, wparam, lparam):
                if code >= 0:
                    try:
                        swallowed, action = self.gate.handle(int(wparam))
                        if swallowed:
                            if action:
                                data = C.cast(lparam, C.POINTER(self.info_type)).contents
                                self.actions.put((action, (data.point.x, data.point.y)))
                            return 1
                    except Exception:
                        # Never let a Python exception cross a native hook boundary.
                        self.gate.enabled = False
                return self.user.CallNextHookEx(hook, code, wparam, lparam)

            self.callback = callback
            hook = self.user.SetWindowsHookExW(14, callback, self.kernel.GetModuleHandleW(None), 0)
            if not hook:
                raise OSError(C.get_last_error(), "Cannot install the mouse hook")
            message = W.MSG()
            # PeekMessage creates the thread queue before ready is signaled.
            self.user.PeekMessageW(C.byref(message), None, 0, 0, 0)
            self.ready.set()
            while not self.stopped.is_set():
                result = self.user.GetMessageW(C.byref(message), None, 0, 0)
                if result == -1:
                    raise OSError(C.get_last_error(), "Mouse hook message loop failed")
                if result == 0:
                    break
                # Low-level hook callbacks run while GetMessage dispatches sent messages.
        except Exception as exc:
            self.error = f"Mouse controls unavailable: {exc}"
            self.actions.put(("hook_error", self.error))
        finally:
            self.gate.enabled = False
            self.ready.set()
            if hook:
                self.user.UnhookWindowsHookEx(hook)

    def stop(self):
        self.gate.enabled = False
        self.stopped.set()
        if self.thread_id:
            self.user.PostThreadMessageW(self.thread_id, 0x0012, 0, 0)
        if self.thread.is_alive():
            self.thread.join(timeout=1)


@dataclass
class Capture:
    hwnd: int
    pid: int
    thread: int
    summary: dict[str, Any]
    started: str = field(default_factory=timestamp)
    expected_created: float | None = None
    report: str | None = None
    copy_requested: bool = False
    future: Any = None


class NativeDetails:
    def __init__(self, api):
        self.api = api
        self.user = api.user
        self.kernel = C.WinDLL("kernel32", use_last_error=True)
        self.advapi = C.WinDLL("advapi32", use_last_error=True)
        self.version = C.WinDLL("version", use_last_error=True)

        def bind(dll, name, result, *args):
            fn = getattr(dll, name)
            fn.restype, fn.argtypes = result, list(args)
            return fn

        self.client_rect = bind(self.user, "GetClientRect", W.BOOL, W.HWND, C.POINTER(W.RECT))
        self.map_points = bind(self.user, "MapWindowPoints", C.c_int, W.HWND, W.HWND, C.c_void_p, W.UINT)
        self.parent = bind(self.user, "GetParent", W.HWND, W.HWND)
        self.zoomed = bind(self.user, "IsZoomed", W.BOOL, W.HWND)
        self.unicode = bind(self.user, "IsWindowUnicode", W.BOOL, W.HWND)
        self.menu = bind(self.user, "GetMenu", W.HMENU, W.HWND)
        self.help_id = bind(self.user, "GetWindowContextHelpId", W.DWORD, W.HWND)
        self.placement = bind(self.user, "GetWindowPlacement", W.BOOL, W.HWND, C.c_void_p)
        self.gui_info = bind(self.user, "GetGUIThreadInfo", W.BOOL, W.DWORD, C.c_void_p)
        self.enum_children = bind(self.user, "EnumChildWindows", W.BOOL, W.HWND, api.enum_type, W.LPARAM)
        self.props_type = C.WINFUNCTYPE(C.c_int, W.HWND, C.c_void_p, W.HANDLE, C.c_size_t)
        self.enum_props = bind(self.user, "EnumPropsExW", C.c_int, W.HWND, self.props_type, W.LPARAM)
        suffix = "PtrW" if C.sizeof(C.c_void_p) == 8 else "W"
        self.class_long = bind(self.user, "GetClassLong" + suffix, C.c_size_t, W.HWND, C.c_int)
        self.layer_attributes = bind(self.user, "GetLayeredWindowAttributes", W.BOOL,
                                     W.HWND, C.POINTER(W.DWORD), C.POINTER(W.BYTE), C.POINTER(W.DWORD))
        self.open_process = bind(self.kernel, "OpenProcess", W.HANDLE, W.DWORD, W.BOOL, W.DWORD)
        self.close_handle = bind(self.kernel, "CloseHandle", W.BOOL, W.HANDLE)
        self.priority = bind(self.kernel, "GetPriorityClass", W.DWORD, W.HANDLE)
        self.session = bind(self.kernel, "ProcessIdToSessionId", W.BOOL, W.DWORD, C.POINTER(W.DWORD))
        self.query_image = bind(self.kernel, "QueryFullProcessImageNameW", W.BOOL,
                                W.HANDLE, W.DWORD, W.LPWSTR, C.POINTER(W.DWORD))
        self.open_token = bind(self.advapi, "OpenProcessToken", W.BOOL,
                               W.HANDLE, W.DWORD, C.POINTER(W.HANDLE))
        self.token_info = bind(self.advapi, "GetTokenInformation", W.BOOL,
                               W.HANDLE, C.c_int, C.c_void_p, W.DWORD, C.POINTER(W.DWORD))
        self.sid_count = bind(self.advapi, "GetSidSubAuthorityCount", C.POINTER(W.BYTE), C.c_void_p)
        self.sid_part = bind(self.advapi, "GetSidSubAuthority", C.POINTER(W.DWORD), C.c_void_p, W.DWORD)
        self.package = bind(self.kernel, "GetPackageFullName", W.LONG,
                            W.HANDLE, C.POINTER(W.UINT), W.LPWSTR)
        self.app_id = bind(self.kernel, "GetApplicationUserModelId", W.LONG,
                           W.HANDLE, C.POINTER(W.UINT), W.LPWSTR)
        self.event_type = C.WINFUNCTYPE(None, W.HANDLE, W.DWORD, W.HWND,
                                        W.LONG, W.LONG, W.DWORD, W.DWORD)
        self.event_hook = bind(self.user, "SetWinEventHook", W.HANDLE,
                               W.DWORD, W.DWORD, W.HMODULE, self.event_type,
                               W.DWORD, W.DWORD, W.DWORD)
        self.unhook_event = bind(self.user, "UnhookWinEvent", W.BOOL, W.HANDLE)
        self.version_size = bind(self.version, "GetFileVersionInfoSizeW", W.DWORD,
                                 W.LPCWSTR, C.POINTER(W.DWORD))
        self.version_info = bind(self.version, "GetFileVersionInfoW", W.BOOL,
                                 W.LPCWSTR, W.DWORD, W.DWORD, C.c_void_p)
        self.query_version = bind(self.version, "VerQueryValueW", W.BOOL,
                                  C.c_void_p, W.LPCWSTR, C.POINTER(C.c_void_p), C.POINTER(W.UINT))

    @staticmethod
    def checked(ok):
        if not ok:
            raise OSError(C.get_last_error(), "Windows API call failed")

    @staticmethod
    def rect_value(rect):
        return [rect.left, rect.top, rect.right, rect.bottom]

    @staticmethod
    def long_value(getter, hwnd, index):
        C.set_last_error(0)
        value = getter(hwnd, index)
        error = C.get_last_error()
        if not value and error:
            raise OSError(error, "Window/class value query failed")
        return hex(value & ((1 << (C.sizeof(C.c_void_p) * 8)) - 1))

    def window(self, hwnd, thread):
        api = self.api
        result = {
            "hwnd": hex(hwnd), "title": api.text(api.title, hwnd),
            "class": api.text(api.class_name, hwnd), "pid_and_thread": api.process_id(hwnd),
            "window_rect": api.bounds(hwnd, False), "DWM_frame_rect": api.bounds(hwnd),
            "style": f"0x{api.get_long(hwnd, -16) & 0xFFFFFFFF:08X}",
            "extended_style": f"0x{api.get_long(hwnd, -20) & 0xFFFFFFFF:08X}",
            "visible": bool(api.visible(hwnd)), "enabled": bool(api.enabled(hwnd)),
            "minimized": bool(api.iconic(hwnd)), "maximized": bool(self.zoomed(hwnd)),
            "unicode": bool(self.unicode(hwnd)), "foreground_hwnd": hex(api.foreground() or 0),
            "parent_hwnd": hex(self.parent(hwnd) or 0), "owner_hwnd": hex(api.owner(hwnd, 4) or 0),
            "root_hwnd": hex(api.ancestor(hwnd, 2) or 0),
            "root_owner_hwnd": hex(api.ancestor(hwnd, 3) or 0),
            "menu_handle": hex(self.menu(hwnd) or 0), "context_help_id": self.help_id(hwnd),
            "window_id_or_userdata": {str(i): read(lambda i=i: self.long_value(api.get_long, hwnd, i))
                                      for i in (-12, -21)},
        }

        def client():
            rect = W.RECT()
            self.checked(self.client_rect(hwnd, C.byref(rect)))
            local = self.rect_value(rect)
            self.map_points(hwnd, None, C.byref(rect), 2)
            return {"local": local, "screen": self.rect_value(rect)}

        result["client_rect"] = read(client)

        class Placement(C.Structure):
            _fields_ = [("length", W.UINT), ("flags", W.UINT), ("show_command", W.UINT),
                        ("min_position", W.POINT), ("max_position", W.POINT), ("normal", W.RECT)]

        def placement():
            value = Placement()
            value.length = C.sizeof(value)
            self.checked(self.placement(hwnd, C.byref(value)))
            return {"flags": value.flags, "show_command": value.show_command,
                    "min_position": [value.min_position.x, value.min_position.y],
                    "max_position": [value.max_position.x, value.max_position.y],
                    "normal_rect_workspace_coordinates": self.rect_value(value.normal)}

        result["placement"] = read(placement)

        class GuiInfo(C.Structure):
            _fields_ = [("size", W.DWORD), ("flags", W.DWORD), ("active", W.HWND),
                        ("focus", W.HWND), ("capture", W.HWND), ("menu_owner", W.HWND),
                        ("move_size", W.HWND), ("caret", W.HWND), ("caret_rect", W.RECT)]

        def gui():
            value = GuiInfo()
            value.size = C.sizeof(value)
            self.checked(self.gui_info(thread, C.byref(value)))
            return {**{name: hex(getattr(value, name) or 0)
                       for name in ("active", "focus", "capture", "menu_owner", "move_size", "caret")},
                    "flags": value.flags, "caret_rect": self.rect_value(value.caret_rect)}

        result["GUI_thread"] = read(gui)
        properties = []

        @self.props_type
        def prop_callback(_, name, value, __):
            try:
                key = f"ATOM {name or 0}" if not name or name < 65536 else C.wstring_at(name)
                properties.append({"name": key, "value_handle": hex(value or 0)})
            except Exception as exc:
                properties.append(unavailable(exc))
            return 1

        self.enum_props(hwnd, prop_callback, 0)
        result["window_properties"] = properties
        result["class_values"] = {name: read(lambda index=index: self.long_value(self.class_long, hwnd, index)) for name, index in [
            ("style", -26), ("atom", -32), ("module", -16), ("window_proc", -24),
            ("icon", -14), ("small_icon", -34), ("cursor", -12), ("background_brush", -10),
            ("class_extra_bytes", -20), ("window_extra_bytes", -18)]}
        children = []

        @api.enum_type
        def child_callback(child, _):
            try:
                children.append({"hwnd": hex(child), "class": api.text(api.class_name, child),
                                 "title_via_GetWindowText": api.text(api.title, child),
                                 "pid_and_thread": api.process_id(child),
                                 "rect": api.bounds(child, False), "visible": bool(api.visible(child)),
                                 "enabled": bool(api.enabled(child)),
                                 "style": f"0x{api.get_long(child, -16) & 0xFFFFFFFF:08X}",
                                 "extended_style": f"0x{api.get_long(child, -20) & 0xFFFFFFFF:08X}"})
            except Exception as exc:
                children.append(unavailable(exc))
            return True

        self.enum_children(hwnd, child_callback, 0)
        result["native_descendant_windows"] = children
        result["DWM_attributes"] = {}
        for index, name in [(1, "nonclient_rendering_enabled"), (14, "cloaked"),
                            (15, "freeze_representation"), (20, "immersive_dark_mode"),
                            (33, "corner_preference"), (34, "border_color"),
                            (35, "caption_color"), (36, "text_color"),
                            (37, "visible_frame_border_thickness"), (38, "system_backdrop_type")]:
            value = W.DWORD()
            hresult = api.attr(hwnd, index, C.byref(value), C.sizeof(value))
            result["DWM_attributes"][name] = (value.value if hresult == 0 else
                unavailable("Attribute unavailable or unsupported", HRESULT=f"0x{hresult & 0xFFFFFFFF:08X}"))
        color, alpha, flags = W.DWORD(), W.BYTE(), W.DWORD()
        result["layer_attributes"] = ({"color_key": color.value, "alpha": alpha.value, "flags": flags.value}
            if self.layer_attributes(hwnd, C.byref(color), C.byref(alpha), C.byref(flags)) else
            unavailable("No queryable constant-alpha/color-key layer attributes", winerror=C.get_last_error()))
        return result

    def process(self, pid):
        session = W.DWORD()
        result = {"session_id": session.value if self.session(pid, C.byref(session)) else
                  unavailable("ProcessIdToSessionId failed", winerror=C.get_last_error())}
        handle = self.open_process(0x1000, False, pid)
        if not handle:
            result["query_handle"] = unavailable("OpenProcess failed", winerror=C.get_last_error())
            return result
        try:
            result["priority_class"] = self.priority(handle)
            size = W.DWORD(32768)
            buffer = C.create_unicode_buffer(size.value)
            result["image_path"] = buffer.value if self.query_image(handle, 0, buffer, C.byref(size)) else unavailable(
                "QueryFullProcessImageName failed", winerror=C.get_last_error())
            if hasattr(self.kernel, "IsWow64Process2"):
                fn = self.kernel.IsWow64Process2
                fn.argtypes, fn.restype = [W.HANDLE, C.POINTER(W.WORD), C.POINTER(W.WORD)], W.BOOL
                process_machine, native_machine = W.WORD(), W.WORD()
                result["architecture"] = ({"process_machine": hex(process_machine.value),
                    "native_machine": hex(native_machine.value)} if fn(handle, C.byref(process_machine), C.byref(native_machine))
                    else unavailable("IsWow64Process2 failed", winerror=C.get_last_error()))
            else:
                result["architecture"] = unavailable("IsWow64Process2 is unsupported by this Windows version")
            for name, fn in [("package_full_name", self.package), ("application_user_model_id", self.app_id)]:
                length = W.UINT()
                code = fn(handle, C.byref(length), None)
                if code == 122:
                    text = C.create_unicode_buffer(length.value)
                    code = fn(handle, C.byref(length), text)
                    result[name] = text.value if code == 0 else unavailable("Query failed", winerror=code)
                else:
                    result[name] = unavailable("No identity or query unavailable", winerror=code)
            token = W.HANDLE()
            if self.open_token(handle, 8, C.byref(token)):
                try:
                    result["token"] = {}
                    for info_class, name in [(18, "elevation_type"), (20, "elevated"), (26, "UIAccess")]:
                        value, returned = W.DWORD(), W.DWORD()
                        result["token"][name] = (value.value if self.token_info(token, info_class, C.byref(value),
                            C.sizeof(value), C.byref(returned)) else unavailable("Token query failed", winerror=C.get_last_error()))
                    result["token"]["integrity"] = read(lambda: self.integrity(token))
                finally:
                    self.close_handle(token)
            else:
                result["token"] = unavailable("OpenProcessToken failed", winerror=C.get_last_error())
        finally:
            self.close_handle(handle)
        return result

    def integrity(self, token):
        length = W.DWORD()
        self.token_info(token, 25, None, 0, C.byref(length))
        if not length.value:
            raise OSError(C.get_last_error(), "Token integrity length query failed")
        buffer = C.create_string_buffer(length.value)
        self.checked(self.token_info(token, 25, buffer, length, C.byref(length)))
        sid = C.cast(buffer, C.POINTER(C.c_void_p))[0]
        count = self.sid_count(sid)[0]
        if not count:
            raise RuntimeError("Integrity SID has no sub-authorities")
        rid = self.sid_part(sid, count - 1)[0]
        names = {0: "Untrusted", 4096: "Low", 8192: "Medium", 8448: "Medium Plus",
                 12288: "High", 16384: "System", 20480: "Protected"}
        return {"RID": rid, "level": names.get(rid, "Other")}

    def executable(self, path):
        result = {"path": path, "stat": read(lambda: self.file_stat(path)),
                  "version": read(lambda: self.file_version(path))}
        return result

    @staticmethod
    def file_stat(path):
        stat = os.stat(path)
        return {key: getattr(stat, key) for key in dir(stat) if key.startswith("st_")}

    def file_version(self, path):
        unused = W.DWORD()
        size = self.version_size(path, C.byref(unused))
        self.checked(size)
        data = C.create_string_buffer(size)
        self.checked(self.version_info(path, 0, size, data))
        pointer, length = C.c_void_p(), W.UINT()
        self.checked(self.query_version(data, "\\", C.byref(pointer), C.byref(length)))
        fixed = C.cast(pointer, C.POINTER(C.c_uint32))
        values = [fixed[i] for i in range(min(13, length.value // 4))]
        result = {"fixed_info_DWORDs": values}
        if len(values) >= 6:
            result["file_version"] = ".".join(str(v) for v in [values[2] >> 16, values[2] & 65535, values[3] >> 16, values[3] & 65535])
            result["product_version"] = ".".join(str(v) for v in [values[4] >> 16, values[4] & 65535, values[5] >> 16, values[5] & 65535])
        translations = [(0x0409, 0x04B0)]
        if self.query_version(data, "\\VarFileInfo\\Translation", C.byref(pointer), C.byref(length)):
            words = C.cast(pointer, C.POINTER(C.c_uint16))
            translations = [(words[i], words[i + 1]) for i in range(0, length.value // 2 - 1, 2)]
        result["strings"] = {}
        for language, codepage in translations:
            strings = {}
            for key in ("CompanyName", "FileDescription", "FileVersion", "InternalName", "LegalCopyright",
                        "LegalTrademarks", "OriginalFilename", "ProductName", "ProductVersion", "Comments",
                        "PrivateBuild", "SpecialBuild"):
                query = f"\\StringFileInfo\\{language:04x}{codepage:04x}\\{key}"
                if self.query_version(data, query, C.byref(pointer), C.byref(length)):
                    strings[key] = C.wstring_at(pointer, max(0, length.value - 1))
            result["strings"][f"{language:04x}{codepage:04x}"] = strings
        return result


def collect_process(psutil, process):
    getters = ["pid", "name", "exe", "cmdline", "cwd", "username", "ppid", "create_time", "status",
               "terminal", "num_threads", "threads", "num_handles", "cpu_times", "cpu_affinity",
               "memory_info", "memory_full_info", "memory_percent", "io_counters", "open_files",
               "nice", "ionice", "environ", "num_ctx_switches", "is_running"]
    data = {}
    for name in getters:
        def get(name=name):
            value = getattr(process, name)
            return value() if callable(value) else value
        data[name] = read(get)
    data["cpu_percent_100ms_sample"] = read(lambda: process.cpu_percent(interval=0.1))
    data["memory_maps_ungrouped"] = read(lambda: process.memory_maps(grouped=False))
    data["network_connections"] = read(lambda: process.net_connections(kind="all"))

    def related(item):
        return {"pid": item.pid, "name": read(item.name), "exe": read(item.exe),
                "create_time": read(item.create_time)} if item else None

    data["parent"] = read(lambda: related(process.parent()))
    data["children"] = read(lambda: [related(child) for child in process.children(recursive=False)])
    return data


def collect_report(api, native, psutil, capture):
    """Collect once. Re-copying a frozen report never calls these APIs again."""
    data = {"tool": "Screen App Inspect 2.0", "capture_started": capture.started,
            "selected_window": dict(capture.summary), "window": None, "process": None}
    process = None
    identity_mismatch = False
    try:
        process = psutil.Process(capture.pid)
    except Exception as exc:
        data["process"] = unavailable(f"{type(exc).__name__}: {exc}")
    if process is not None:
        created = read(process.create_time)
        if isinstance(created, (int, float)) and capture.expected_created is not None and created != capture.expected_created:
            identity_mismatch = True
            process = None
            data["process"] = unavailable("PID was reused; replacement process was not inspected")
        elif not isinstance(created, (int, float)):
            data["process_identity_validation"] = created
    if not identity_mismatch and api.valid(capture.hwnd) and api.process_id(capture.hwnd) == (capture.pid, capture.thread):
        data["window"] = read(lambda: native.window(capture.hwnd, capture.thread))
        if not api.valid(capture.hwnd) or api.process_id(capture.hwnd) != (capture.pid, capture.thread):
            data["window_identity_after_collection"] = unavailable("Window disappeared or handle was reused during collection")
    else:
        data["window"] = unavailable("Selected window disappeared or its handle/PID was reused")
    if process is not None:
        data["process"] = collect_process(psutil, process)
        running = read(process.is_running)
        if running is True:
            data["native_process"] = read(lambda: native.process(capture.pid))
            executable = data["process"].get("exe")
            if isinstance(executable, str) and executable:
                data["executable_file"] = read(lambda: native.executable(executable))
        else:
            data["identity_after_collection"] = (running if isinstance(running, dict) else
                unavailable("Process exited while the report was being collected"))
    if data["window"] is None:
        data["window"] = unavailable("Window metadata could not be queried safely after process identity validation")
    data["capture_completed"] = timestamp()
    data["scope"] = [
        "Unabridged values returned by the implemented Windows and psutil queries.",
        "Reads take place between capture_started and capture_completed; this is not an atomic OS snapshot.",
        "This report can include process environment variables, open file paths, and network endpoints.",
        "Unavailable, unsupported, exited, or denied fields are recorded separately.",
        "Application-private objects, arbitrary process memory, OCR, UI Automation, and browser DOM data are outside this report.",
        "Native child titles use GetWindowText; custom control text may be unavailable.",
        "System-hosted notifications may identify their renderer rather than their sender.",
    ]
    return json.dumps(json_value(data), ensure_ascii=False, indent=2, allow_nan=False)
