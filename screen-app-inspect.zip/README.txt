SCREEN APP INSPECT

Requirements
------------
Windows 10 or Windows 11; Python 3.10+ with Tcl/Tk; psutil.
The standard Python installer from python.org includes Tcl/Tk by default.
64-bit Python is recommended on 64-bit Windows.

Quick start
-----------
1. Extract this ZIP into a folder.
2. Open Terminal in that folder.
3. Install the dependency:
       py -m pip install -r requirements.txt
4. Start the inspector:
       py screen_app_inspect.py
   You can also double-click run.cmd after installing the dependency.

Move the mouse over a visible application window. A click-through tooltip
follows the pointer and shows the title, process, PID/thread, topmost status,
executable path, and window class. It shows "No window found" over excluded
windows or when no eligible window is detected.

Shortcuts
---------
Ctrl+Alt+D   Toggle compact/expanded details.
Ctrl+Alt+F   Freeze/resume the currently displayed snapshot.
Ctrl+Alt+C   Copy the full, unabridged report to the Windows clipboard.
Ctrl+Alt+Q   Exit.

The tooltip follows the mouse even when the inspected snapshot is frozen.
Close another instance or an app using one of these shortcuts if startup
reports that a shortcut is unavailable.

Options
-------
py screen_app_inspect.py --details
py screen_app_inspect.py --include-explorer
py screen_app_inspect.py --interval 150 --width 650

Explorer app windows are excluded by default. Desktop and taskbar windows
remain excluded even with --include-explorer. Hidden, minimized, and DWM-cloaked
windows are excluded. Disabled and click-through windows can still be detected.

Expanded information
--------------------
HWND, window class, owning process and thread, executable, reconstructed command
line, working directory, user, parent PID, bounds, size, owner HWND, native child
HWND when available, enabled/foreground state, styles, and extended-style flags.
Tooltip text is abbreviated to fit the screen. Copy the report for full values.

Limits
------
- Access restrictions can hide process fields. They appear as
  "Unavailable (access denied)". Running Terminal as administrator can expose
  more metadata for elevated apps, but protected processes may remain restricted.
- A Windows notification can be rendered by a system host on behalf of another
  app. The reported process identifies the renderer, not necessarily its sender.
- A native window title may be empty. Window class and process still help
  identify the window. The tool does not read notification body text through UI
  Automation, OCR, browser DOMs, or custom-drawn application controls.
- Hit detection uses window Z order, DWM bounds, and explicit window regions.
  Per-pixel alpha holes, DirectComposition surfaces, and unusual transparent
  overlays can produce approximate results. It cannot identify every visible
  graphic as a separate native window.
- Secure desktops, the UAC secure screen, other sessions, and exclusive full-screen
  rendering are outside the tool's supported inspection surface.
- Topmost reports WS_EX_TOPMOST; it does not promise a window is visually above
  every possible system surface. Owner HWND is included for additional context.
- Command lines are reconstructed from arguments; original quoting may differ.
- Window metadata refreshes up to four times per second; process metadata is
  cached for up to 1.5 seconds. A short-lived popup can disappear between polls.

Privacy and behavior
--------------------
The script reads window and process metadata. It does not execute an inspected
command, close or change other windows, automatically request elevation, collect
screenshots, or send data over the network. Reports are copied only when you
press the copy shortcut.

Validation
----------
Python syntax and 12 mocked logic tests passed in a Linux environment. The tests
cover window selection, exclusions, access errors, report data, 64-bit handle
formatting, and tooltip placement on monitors with negative coordinates.
The Win32 integration and interactive Windows GUI have not been run here.
