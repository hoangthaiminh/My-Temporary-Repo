SCREEN APP INSPECT 2.0

Requirements
------------
Windows 10/11; Python 3.10+ with Tcl/Tk; psutil 6.0+.
64-bit Python is recommended on 64-bit Windows.

Quick start
-----------
1. Extract the entire ZIP. Keep both Python files in the same folder.
2. Open Terminal in the extracted folder.
3. Install the dependency:
       py -m pip install -r requirements.txt
4. Start:
       py screen_app_inspect.py
   You can also double-click run.cmd after installing the dependency.

Controls
--------
Move the mouse over a visible application window.
LEFT CLICK:   Freeze the selection and collect its full report in the background.
LEFT AGAIN:   Resume live inspection.
RIGHT CLICK:  Copy a full report. While frozen, copy the saved frozen report.

While inspection is active, left/right button presses and releases are captured
globally and are NOT delivered to the underlying applications. Movement, wheel,
and middle-button events pass through. The tooltip itself is click-through.

Ctrl+Alt+M: Pause/resume inspection. While paused, the tooltip is hidden and
            normal mouse clicks are restored.
Ctrl+Alt+F: Freeze/resume (keyboard alternative).
Ctrl+Alt+C: Copy the full report (keyboard alternative).
Ctrl+Alt+Q: Quit and restore normal mouse behavior.

If a mouse hook cannot be installed, the tool falls back to the keyboard controls.
If a hotkey is unavailable, close another inspector instance or the app using it.

Compact tooltip
---------------
The tooltip always shows identification only: title, process, PID/thread,
topmost status, and executable path. There is no expanded-tooltip mode.
Its text is shortened to fit the screen; the copied report is not shortened.
Desktop, taskbar, and Explorer windows are excluded by default.

Full reports and freezing
-------------------------
Copied reports are formatted JSON text. Collection runs on a separate thread.
If you copy while collection is running, copying is queued and happens when that
specific report is ready. A frozen report is collected once and retained in
memory. Re-copying it never re-reads the application, even if it has changed or
closed. If you resume before a requested copy completes, that request still copies
the originally selected report. Only one collection runs at a time.

Included where available:
- Window title/class/handles, process/thread identity, window/client/frame bounds,
  placement, styles, extended flags, owner/parent/root, visibility, enabled state,
  menu/help IDs, class values, window properties, GUI-thread state, native child
  windows, layered-window settings, and DWM attributes.
- Process identity, arguments, executable, working directory, account, creation
  time, status, parent/children, threads, handles, CPU information, affinity,
  priority, memory counters/maps, I/O, open files, network connections, environment,
  and other supported psutil fields.
- Session, architecture, token elevation/integrity/UIAccess, package/application
  identity, executable file metadata and version-resource strings.

Reports can include environment variables, open file paths, and network endpoints.
The tool only places reports on the local clipboard when you request a copy.

There is no universal API for every private property of every application. The
report contains all returned values from its implemented queries, with no display
truncation. Unsupported/denied/exited fields have individual availability/error
records. It does not dump arbitrary process memory, read browser DOMs, perform
OCR, or enumerate UI Automation objects. Native child titles use GetWindowText;
custom-drawn control text may be unavailable.

A report is a best-effort capture over the interval recorded in capture_started
and capture_completed, not an atomic OS snapshot. Freeze pins the target and its
report at selection time, but individual APIs return values as they are queried.
Metadata already inaccessible when collection starts cannot be reconstructed.
Process creation times help reject a reused PID.

Overlay behavior
----------------
The overlay is layered, click-through, non-activating, and topmost. It reasserts
its position periodically and reacts to other processes' foreground/show/hide/
reorder events. It does not activate or change the inspected application.

This improves visibility above ordinary always-on-top windows. Another application
may briefly cover it between updates. Windows has higher privileged/system Z-order
bands: this ordinary Python process cannot guarantee visibility above UIAccess
windows, secure/UAC desktops, protected system surfaces, hardware overlays, or
exclusive full-screen rendering. Running as administrator does not grant UIAccess.
A properly packaged, signed, trusted-location UIAccess executable is a separate
deployment option; this ZIP does not change UIAccess, registry policy, or security.
Drawing directly onto the desktop is not a reliable compositor-independent fix.

Options
-------
py screen_app_inspect.py --keyboard-only
py screen_app_inspect.py --start-paused
py screen_app_inspect.py --include-explorer
py screen_app_inspect.py --interval 50 --width 480

--keyboard-only leaves all mouse buttons available to applications.
--start-paused waits for Ctrl+Alt+M before showing the overlay/capturing clicks.
--include-explorer includes Explorer app windows; desktop/taskbar stay excluded.

Other limits
------------
Elevated or protected processes can deny metadata access. Starting Terminal as
administrator can expose more fields, but protected data may remain inaccessible.
Notification windows can belong to a system host that renders another app's
notification; the owning process does not always identify the original sender.
Hit detection uses Z order, DWM bounds, and window regions. Per-pixel alpha holes
and unusual compositor overlays can be approximate. Other sessions and secure
desktops are outside the supported inspection surface.

Validation
----------
Python syntax and 29 mocked logic tests passed on Linux. Tests cover window
selection, exclusions, mouse press/release pairing, pause, frozen report reuse,
queued copy, PID reuse, partial access errors, unabridged reports, compact-only
tooltips, and monitor placement with negative coordinates.
The actual Win32 mouse hook, WinEvent hooks, metadata APIs and interactive Windows
GUI have not been run in this environment.
